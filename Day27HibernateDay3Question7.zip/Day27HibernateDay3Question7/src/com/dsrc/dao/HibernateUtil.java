package com.dsrc.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.dsrc.model.Customer;
import com.dsrc.model.Login;
import com.dsrc.model.Product;
import com.dsrc.model.Staff;
import com.dsrc.view.MenuScreen;

public class HibernateUtil 
{
	public boolean checkLogin(String loginId, String password)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Login.class).buildSessionFactory();
		Session session=sx.openSession();
		Transaction transaction=session.beginTransaction();
		List lst = session.createQuery("FROM Login").list(); 
          for (Iterator iterator = lst.iterator(); iterator.hasNext();){
              Login l = (Login) iterator.next(); 
         {
		if(l.getLoginId().equals(loginId) && l.getPassword().equals(password))
		{
		MenuScreen ms=new MenuScreen();
		ms.showMenu();
		}
         }
 
	}  
          System.out.println("Invalid");
		return true;
		}
	
	
	public boolean saveProduct(Product product)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		s.save(product);
		t.commit();
		System.out.println("Done......");
		return true;
	}
	// To Be Coded..	
	public boolean saveStaff(Staff staff)
	{
		return true;
	}
	public boolean updateStaff(Staff staff)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		s.saveOrUpdate(staff);
		t.commit();
		s.close();
		return true;
	}
	public boolean deleteStaff(Staff staff)
	{

		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
		Session s= sx.openSession();
		String hql ="DELETE FROM Staff P Where P.staffid=?";
		Transaction t=s.beginTransaction();
		Staff st=(Staff)s.get(Staff.class, staff.getStaffid());
		s.delete(st);
		t.commit();
		s.close();
		System.out.println("deleted.............");
		return true;
		
	}
	
	public boolean updateProduct(Product product)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		s.update(product);
		t.commit();
		System.out.println("Done......");
		return true;
		
	}
	public boolean deleteProduct(Product product)
	{
		
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		 product=(Product) s.get(Product.class, product.getProductid());
		s.delete(product);
		t.commit();
		s.close();
		return true;
	}
	public List<Product> selectAllProducts()
	{
		return null;
		
	}

	public List<Product> searchByID(int productid)
	{
		return null;
		
	}
	public List<Product> searchByname(String name)
	{
		return null;
		
	}

	public List<Product> searchByrange(int fromPrice,int toPrice)
	{
		return null;
		
	}
	
	public boolean saveCustomer(Customer customer)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Customer.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		s.save(customer);
		t.commit();
		s.close();
		System.out.println("saved.............");
		
		return true;
	}
	public boolean editCustomer(Customer customer)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Customer.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		s.update(customer);
		t.commit();
		s.close();
		System.out.println("edited.............");
		return true;
	}
	public boolean deleteCustomer(Customer customer)
	{

		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Customer.class).buildSessionFactory();
		Session s= sx.openSession();
	//	String hql ="DELETE FROM Customer P Where P.customerid=?";
		Transaction t=s.beginTransaction();
		Customer c=(Customer)s.get(Customer.class, customer.getCustomerid());
		s.delete(c);
		t.commit();
		s.close();
		System.out.println("deleted.............");
		return true;
		
	}

	
}
