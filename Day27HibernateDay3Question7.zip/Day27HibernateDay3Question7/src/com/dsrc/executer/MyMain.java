package com.dsrc.executer;

import com.dsrc.view.LoginScreen;
import com.dsrc.view.MenuScreen;

public class MyMain 
{
		public static void main(String[] args) 
		{
			System.out.println("--PMS---");
			System.out.println("..Welcome to Product Management System..");
			LoginScreen ls=new LoginScreen();
			ls.showLoginScreen();
		}
}
