package com.dsrc.model;

import javax.persistence.*;

@Entity
@Table(name="Product")
public class Product {
	// Create variables and getters and setters..
	
	@Id
	@Column(name="productid")
	private int productid;
	
	@Column(name="productname")
	private String productname;
	
	@Column(name="productprice")
	private int productprice;
	
	public Product(){
	}
	
	public Product(int productid, String productname, int productprice)
	{
		this.productid=productid;
		this.productname=productname;
		this.productprice=productprice;
		
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}
}
