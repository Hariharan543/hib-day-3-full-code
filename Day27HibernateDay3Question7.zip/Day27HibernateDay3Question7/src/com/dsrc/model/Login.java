package com.dsrc.model;
import javax.persistence.*;
@Entity 
@Table(name="Login")
public class Login {
	
	@Id
	@Column(name="LoginId")
	private String LoginId;

	@Column(name="Password")
	private String Password;
	
	public Login(){}
	
	public Login(String LoginId,String Password)
	{
		this.LoginId=LoginId;
		this.Password=Password;
		
	}

	public String getLoginId() {
		return LoginId;
	}

	public void setLoginId(String loginId) {
		LoginId = loginId;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

}
