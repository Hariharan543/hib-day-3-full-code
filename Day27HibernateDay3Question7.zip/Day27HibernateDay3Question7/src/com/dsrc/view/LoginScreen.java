package com.dsrc.view;
import java.util.Scanner;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.model.Login;
public class LoginScreen {
	public boolean showLoginScreen()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter LoginID");
		String loginid=sc.next();
		
		System.out.println("Enter Password");
		String password=sc.next();
		
		Login login=new Login();
		boolean res=new HibernateUtil().checkLogin(loginid,password);
		
		return true;
		
	}

}
