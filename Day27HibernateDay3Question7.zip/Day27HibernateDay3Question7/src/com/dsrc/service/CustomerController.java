package com.dsrc.service;

import com.dsrc.view.CustomerScreen;

public class CustomerController {
	
	public int customerManager()
	{
		CustomerScreen cs= new CustomerScreen();
		cs.showCustomerScreen();
		return 0;
	}
}
