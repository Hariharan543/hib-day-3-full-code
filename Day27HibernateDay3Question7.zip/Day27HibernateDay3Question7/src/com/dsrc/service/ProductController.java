package com.dsrc.service;

import com.dsrc.view.ProductScreen;

public class ProductController
{
		public int productManager()
		{
			ProductScreen ps= new ProductScreen();
			ps.showProductScreen();
			return 0;
		}
}
